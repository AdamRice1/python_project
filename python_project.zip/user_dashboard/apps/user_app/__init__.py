from newsapi import NewsApiClient

newsapi = NewsApiClient(api_key='dda6728a056040faa317235048c946d7')